import microbit
import machine
import utime
import neopixel
from microbit import *
#-------------------------------------------------------------------------
# Clase Maqueen creada para controlar los motores, leds y RGB
# ----> NO TOCAR ESTE CÓDIGO <----
class Maqueen:
	"""
	Clase de Python para la plataforma DFRobot Micro:maqueen
	https://www.dfrobot.com/product-1783.html
	Author: Krzysztof Sawicki <krzysztof@rssi.pl>
	Licencia: GNU
	"""
    #...Función para inicializar el NeoPixel
	def __init__(self):
		self.rgbleds = neopixel.NeoPixel(microbit.pin15, 4)
		print("MAQUEEN inicializado")

    #...#Función para controlar los leds 
	def set_led(self, lednumber, value):   
		"""
    		Habilitar o deshabilitar los LEDS frontales
            0 - LED izquierdo (P8)
            1 - LED derecho (P12)
		"""
		if lednumber == 0:
			microbit.pin8.write_digital(value)
		elif lednumber == 1:
			microbit.pin12.write_digital(value)

    #...Función para utilizar el sensor ultrasónico
	def read_distance(self):   
		"""
    		Lee la distancia del sensor HC SR04
            el resultado esta en centimetros
            Divider se toma de la biblioteca Makecode para micro:maqueen
		"""
		divider = 42
		maxtime = 250 * divider
		microbit.pin2.read_digital()  # just for setting PULL_DOWN on pin2
		microbit.pin1.write_digital(0)
		utime.sleep_us(2)
		microbit.pin1.write_digital(1)
		utime.sleep_us(10)
		microbit.pin1.write_digital(0)
		duration = machine.time_pulse_us(microbit.pin2, 1, maxtime)
		distance = duration/divider
		return distance

    #...Función para usar los sensores siguelíneas
	def read_patrol(self, which): 
		"""
    		Leemos los sensores de tonos grises
		"""
		if which == 0:  # left
			return microbit.pin13.read_digital()
		elif which == 1:  # right
			return microbit.pin14.read_digital()

    #...Función para controlar ambos motores
	def set_motor(self, motor, value):  
		"""
		Controls motor
		motor: 0 - left motor, 1 - right motor
		value: -255 to +255, the sign means direction
		"""
		data = bytearray(3)
		if motor == 0:  # left motor
			data[0] = 0
		else:
			data[0] = 2  # right motor is 2
		if value < 0:  # ccw direction
			data[1] = 1
			value = -1*value
		data[2] = value
		microbit.i2c.write(0x10, data, False)  # 0x10 is i2c address of motor driver

    #...Función para parar los dos motores
	def motor_stop_all(self):    
		self.set_motor(0, 0)
		self.set_motor(1, 0)
#----------------------------------------------------------------------------------